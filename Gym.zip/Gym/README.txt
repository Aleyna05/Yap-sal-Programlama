This project is written in Java programming language.
Mysql database has been used.
Do not forget to import the database to run the project.