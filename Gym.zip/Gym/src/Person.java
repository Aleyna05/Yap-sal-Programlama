/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


public class Person {
    private String name;
    private String surname;
    private String Age;
    private String Gender;
    private String phoneNumber;
    private String adress;
    private float height;
    private float weight;

   
    public String getName() {
        return name;
    }

  
    public void setName(String name) {
        this.name = name;
    }

   
    public String getSurname() {
        return surname;
    }

    
    public void setSurname(String surname) {
        this.surname = surname;
    }

   
    public String getAge() {
        return Age;
    }

   
    public void setAge(String Age) {
        this.Age = Age;
    }

   
    public String getSex() {
        return Gender;
    }

    
    public void setSex(String Sex) {
        this.Gender = Sex;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    
    public String getAdress() {
        return adress;
    }

  
    public void setAdress(String adress) {
        this.adress = adress;
    }

    
    public float getHeight() {
        return height;
    }

    public void setHeight(float height) {
        this.height = height;
    }

   
    public float getWeight() {
        return weight;
    }

    
    public void setWeight(float weight) {
        this.weight = weight;
    }
    
}
